
frutas_lista = ["maçã", "banana", "laranja", "uva", "manga", "morango"]

frutas_tupla = tuple(frutas_lista)

print("Frutas na tupla:")
print(frutas_tupla)

