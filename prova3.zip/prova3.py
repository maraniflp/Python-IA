produtos = {}

print("=== CADASTRO DE PRODUTOS ===")


for i in range(1, 6):
    print(f"\nProduto {i}:")
    nome = input("Digite o nome do produto: ")
    preco = float(input("Digite o preço do produto: R$ "))
    
    produtos[nome] = preco

total = sum(produtos.values())

print("\n" + "="*30)
print("RESUMO DA COMPRA:")
print("="*30)

for produto, preco in produtos.items():
    print(f"{produto}: R$ {preco:.2f}")

print("-"*30)
print(f"TOTAL: R$ {total:.2f}")