
nome = input("Digite o nome: ")
telefone = input("Digite o telefone: ")
email = input("Digite o email: ")

contato = {
    "nome": nome,
    "telefone": telefone,
    "email": email
}

print("\nDados do contato:")
print("Nome:", contato["nome"])
print("Telefone:", contato["telefone"])
print("Email:", contato["email"])